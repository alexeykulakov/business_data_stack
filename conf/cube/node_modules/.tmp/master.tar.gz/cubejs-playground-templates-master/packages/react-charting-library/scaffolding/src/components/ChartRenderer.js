import React from 'react';

const TypeToChartComponent = {};

export default TypeToChartComponent;
