import Chart from 'chart.js';
import VueChartkick from 'vue-chartkick';

Vue.use(VueChartkick, { adapter: Chart });
