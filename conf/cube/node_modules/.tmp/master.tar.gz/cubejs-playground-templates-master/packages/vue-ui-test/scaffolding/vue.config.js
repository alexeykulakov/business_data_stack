module.exports = {
  transpileDependencies: ['vuetify'],
};
